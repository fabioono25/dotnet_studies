﻿using Core.Messages;

namespace Pagamento.Commands
{
    public class RealizarPagamentoCommand : Command
    {

    }
}