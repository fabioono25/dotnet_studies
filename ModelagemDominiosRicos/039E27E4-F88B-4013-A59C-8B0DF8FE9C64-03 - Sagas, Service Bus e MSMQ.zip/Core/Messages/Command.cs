﻿namespace Core.Messages
{
    public abstract class Command : Message
    {

    }
}