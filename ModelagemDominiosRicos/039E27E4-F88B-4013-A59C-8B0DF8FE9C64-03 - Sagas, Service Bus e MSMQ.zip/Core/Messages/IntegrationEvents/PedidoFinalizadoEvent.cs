﻿namespace Core.Messages.IntegrationEvents
{
    public class PedidoFinalizadoEvent : Event
    {

    }
}