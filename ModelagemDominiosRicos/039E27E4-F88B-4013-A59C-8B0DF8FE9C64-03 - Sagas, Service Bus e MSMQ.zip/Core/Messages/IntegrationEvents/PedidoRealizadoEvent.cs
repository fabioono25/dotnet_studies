﻿namespace Core.Messages.IntegrationEvents
{
    public class PedidoRealizadoEvent : Event
    {

    }
}