﻿namespace Core.Messages.IntegrationEvents
{
    public class PagamentoRealizadoEvent : Event
    {

    }
}