﻿namespace Core.Messages.IntegrationEvents
{
    public class PagamentoRecusadoEvent : Event
    {

    }
}