﻿using Core.Messages;

namespace Pedido.Commands
{
    public class RealizarPedidoCommand : Command
    {

    }
}