﻿namespace NerdStore.Core.Messages.CommonMessages.IntegrationEvents
{
    public abstract class IntegrationEvent : Event
    {

    }
}